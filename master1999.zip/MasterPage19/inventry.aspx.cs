﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Configuration;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;

namespace MasterPage19
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                databind();

            }

        }
        public void databind()
        {


            //string conn = ConfigurationManager.ConnectionStrings["myConnection "].ConnectionString;
            //SqlConnection sqlcon = new SqlConnection(conn);
            //string Sqlqry = "select * from inventry ";
            //SqlCommand cmd = new SqlCommand(Sqlqry, sqlcon);
            //sqlcon.Open();

            //SqlDataAdapter ada = new SqlDataAdapter(cmd);

            //DataTable dt = new DataTable();
            //ada.Fill(dt);
            //idddl1.datasource = dt;
            //idddl1.datasourceid = null;
            //idddl1.datatextfield = "id";
            //idddl1.datavaluefield = "id";
            //idddl1.databind();
            //griddt.datasource = dt;
            //grddt.datasourceid = null;
            //idddl1.items.insert(0, "select all");
            //idddl1.selectedindex = 0;
            //Grddt.DataBind();``


            // 2nd DropDownList ItemNmae TAble 

            string con = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sqlcoon = new SqlConnection(con);
            string Sqqry = "select * from Itemname ";
            SqlCommand cmdd = new SqlCommand(Sqqry, sqlcoon);
            sqlcoon.Open();
            SqlDataAdapter adaa = new SqlDataAdapter(cmdd);
            DataTable dt1 = new DataTable();
            adaa.Fill(dt1);
            inameddl.DataSource = dt1;
            inameddl.DataSourceID = null;
            inameddl.DataTextField = "ItemName";
            inameddl.DataValueField = "ID";
            inameddl.DataBind();
            inameddl.Items.Insert(0, "Select All");
            inameddl.SelectedIndex = 0;
            //GridView1.DataBind();

            sqlcoon.Close();
            // dropdown  3 Itemtype 
            string conm = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sqlcn = new SqlConnection(conm);
            string Sqqryy = "select * from ItemType ";
            SqlCommand cdd = new SqlCommand(Sqqryy, sqlcn);
            sqlcn.Open();
            SqlDataAdapter daa = new SqlDataAdapter(cdd);
            DataTable dt2 = new DataTable();
            daa.Fill(dt2);
            itypeddl.DataSource = dt2;
            itypeddl.DataSourceID = null;
            itypeddl.DataTextField = "Itemtype";
            itypeddl.DataValueField = "Id";
            itypeddl.DataBind();
            itypeddl.Items.Insert(0, "Select All");
            itypeddl.SelectedIndex = 0;
            //GridView1.DataBind();
            sqlcn.Close();
            // dropDown4 Employee Allotedto

            string cn = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection scn = new SqlConnection(cn);
            string qry = "select * from Employee ";
            SqlCommand cd = new SqlCommand(qry, scn);
            scn.Open();
            SqlDataAdapter ptr = new SqlDataAdapter(cd);
            DataTable dt3 = new DataTable();
            ptr.Fill(dt3);
            iAlloteddl.DataSource = dt3;
            iAlloteddl.DataSourceID = null;
            iAlloteddl.DataTextField = "Name";
            iAlloteddl.DataValueField = "Id";
            iAlloteddl.DataBind();

            iAlloteddl.Items.Insert(0, "Select All");
            iAlloteddl.SelectedIndex = 0;
            AllotedDatebox.Text = string.Empty;
            Remarkbox.Text = string.Empty;
            /*   GridView1.DataBind()*/
            ;
            scn.Close();
            //new connection

            string comn = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sqln = new SqlConnection(comn);
            string Sqlqy = "select * from inventry ";
            SqlCommand cmJd = new SqlCommand(Sqlqy, sqln);
            sqln.Open();

            SqlDataAdapter adGa = new SqlDataAdapter(cmJd);

            DataTable dt5 = new DataTable();
            adGa.Fill(dt5);
            idddl1.DataSource = dt5;
            idddl1.DataSourceID = null; 
            idddl1.DataTextField = "Id";
            idddl1.DataValueField = "Id";
            idddl1.DataBind();
            Grddt.DataSource = dt5;
            Grddt.DataSourceID = null;

            idddl1.Items.Insert(0, "Select All");
            idddl1.SelectedIndex = 0;
            Grddt.DataBind();
            sqln.Close();
        }

        protected void Insertbtn_Click(object sender, EventArgs e)
        {
             SqlConnection cooon = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            cooon.Open();
            SqlCommand cmdff = cooon.CreateCommand();
            cmdff.CommandType = CommandType.StoredProcedure;
            cmdff.CommandText = "sp_web_Insertinventry";
            cmdff.Parameters.Add("@ItemName", SqlDbType.Int).Value = inameddl.SelectedValue;
            cmdff.Parameters.Add("@ItemType", SqlDbType.Int).Value = itypeddl.SelectedValue;
            cmdff.Parameters.Add("@Allotedto", SqlDbType.Int).Value = iAlloteddl.SelectedValue;
            cmdff.Parameters.Add("@AllotedDate", SqlDbType.Date).Value = AllotedDatebox.Text;
            //cmdff.Parameters.Add("@returnDate", SqlDbType.Date).Value = Returndate.Text;
            cmdff.Parameters.Add("@Remark", SqlDbType.NVarChar).Value = Remarkbox.Text;
            //SqlCommand cmdff = new SqlCommand(@"insert into inventry(ItemName,ItemType,AllotedTo,AllotedDate,Remark) values('" + inameddl.SelectedValue + "', '" + itypeddl.SelectedValue + "' , '" + iAlloteddl.SelectedValue + "' , '" + AllotedDatebox.Text + "',  '" + Remarkbox.Text + "' )", cooon);
            cmdff.ExecuteNonQuery();
            cooon.Close();
            Grddt.DataBind();
            databind();
        }

        protected void Updatebtn_Click(object sender, EventArgs e)
        {
            SqlConnection ckkko = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            ckkko.Open();
            SqlCommand cmmm = ckkko.CreateCommand();
            cmmm.CommandType = CommandType.StoredProcedure;
            cmmm.CommandText = "sp_web_updateinventry";
            cmmm.Parameters.Add("Id", SqlDbType.Int).Value = idddl1.SelectedValue;
            cmmm.Parameters.Add("@ItemName",SqlDbType.Int).Value = inameddl.SelectedValue;
            cmmm.Parameters.Add("ItemType",SqlDbType.Int).Value =itypeddl.SelectedValue;
            cmmm.Parameters.Add("AllotedTo",SqlDbType.Int).Value =iAlloteddl.SelectedValue;
            cmmm.Parameters.Add("@AllotedDate", SqlDbType.Date).Value  = AllotedDatebox.Text;
            cmmm.Parameters.Add("Remark",SqlDbType.NVarChar).Value= Remarkbox.Text;
            cmmm.Parameters.Add("@returnDate", SqlDbType.Date).Value = Returndate.Text;
        
            //SqlCommand cmmm = new SqlCommand(@"update Inventry set ItemName='" + inameddl.SelectedValue + "',ItemType='" + itypeddl.SelectedValue + "',AllotedTo='" + iAlloteddl.SelectedValue + "',AllotedDate='" + AllotedDatebox.Text + "',DOJ='" + Remarkbox.Text + "' where ID='" + idddl1.SelectedValue + "'", ckkko);
            cmmm.ExecuteNonQuery();
            ckkko.Close();
            Grddt.DataBind();
            databind();
        }

        protected void deletebtn_Click(object sender, EventArgs e)
        {
            SqlConnection commnn = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            commnn.Open();
            SqlCommand cmdmmd = new SqlCommand(@"delete from inventry  where ID='" + idddl1.SelectedValue + "'", commnn);
            cmdmmd.ExecuteNonQuery();
            commnn.Close();
            Grddt.DataBind();
            databind();
        }

        protected void IDDDL1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string conn = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(conn);
            string Sqlqry = "";
            if (idddl1.SelectedItem.ToString() == "Select All")
            {
                Sqlqry = "select * from  inventry ";

            }
            else
            {
                Sqlqry = "select * from  inventry  where ID =" + idddl1.SelectedValue;

            }
            //string Sqlqry = "select * from employee where Id= " + DropDownList1.SelectedValue;
            SqlCommand cmd = new SqlCommand(Sqlqry, sqlcon);
            sqlcon.Open();
            SqlDataAdapter ada = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            ada.Fill(dt);
            Grddt.DataSource = dt;
            Grddt.DataBind();

            sqlcon.Close();

        }

        protected void Grddt_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

       

        protected void LinkButton7_Click(object sender, EventArgs e)
        {

            SqlConnection commnn = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            commnn.Open();
            SqlCommand cmdmmd = new SqlCommand(@"delete from inventry  where ID='" + idddl1.SelectedValue + "'", commnn);
            cmdmmd.ExecuteNonQuery();
            commnn.Close();
            Grddt.DataBind();
            databind();
        }

        protected void LinkButton6_Click(object sender, EventArgs e)
        {
            SqlConnection ckkko = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            ckkko.Open();
            SqlCommand cmmm = new SqlCommand(@"update Inventry set ItemName='" + inameddl.SelectedValue + "',ItemType='" + itypeddl.SelectedValue + "',AllotedTo='" + iAlloteddl.SelectedValue + "',AllotedDate='" + AllotedDatebox.Text + "',DOJ='" + Remarkbox.Text + "' where ID='" + idddl1.SelectedValue + "'", ckkko);
            cmmm.ExecuteNonQuery();
            ckkko.Close();
            Grddt.DataBind();
            databind();

        }

       



        ////protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        //{






        //    //    string conn = ConfigurationManager.ConnectionStrings["myConnection "].ConnectionString;
        //    //    SqlConnection sqlcon = new SqlConnection(conn);
        //    //    string Sqlqry = "";
        //    //if (IDDDL1.SelectedItem.ToString() == "Select All")
        //    //{
        //    //    Sqlqry = "select * from inventry";

        //    //}
        //    //else
        //    //{
        //    //    Sqlqry = "select * from inventry where id =" + IDDDL1.SelectedValue;

        //    //}
        //    //    SqlCommand cmd = new SqlCommand(Sqlqry, sqlcon);
        //    //    sqlcon.Open();

        //    //    SqlDataAdapter ada = new SqlDataAdapter(cmd);

        //    //    DataTable dt = new DataTable();
        //    //    ada.Fill(dt);
        //    //    IDDDL1.DataSource = dt;
        //    //    IDDDL1.DataTextField = "Id";
        //    //    IDDDL1.DataValueField = "Id";
        //    //    IDDDL1.DataBind();
        //    //    GridView1.DataSource = dt;
        //    //    GridView1.DataSourceID = null;
        //    //    IDDDL1.Items.Insert(0, "Select All");
        //    //    IDDDL1.SelectedIndex = 0;

        //    //    GridView1.DataBind();
        //    //    sqlcon.Close();
        // }

    }
}