﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Services.Description;
using System.Drawing;
using System.Globalization;

namespace MasterPage19
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        private DataTable Datatextfiled;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                databind();

            }

        }
        public void databind()
        {


            //    string conn = ConfigurationManager.ConnectionStrings["myConnection "].ConnectionString;
            //    SqlConnection sqlcon = new SqlConnection(conn);
            //    string Sqlqry = "select * from employee ";
            //    SqlCommand cmd = new SqlCommand(Sqlqry, sqlcon);
            //    sqlcon.Open();
            //    //cmd.CommandText = Sqlqry;
            //    //cmd.Connection = sqlcon;
            //    //cmd.Parameters.AddWithValue("Name", TxtSearch.Text);
            //    //DataTable dt = new DataTable();
            //    SqlDataAdapter ada = new SqlDataAdapter(cmd);

            //    DataTable dt = new DataTable();
            //    ada.Fill(dt);
            //    DropDownList1.DataSource = dt;
            //    DropDownList1.DataSourceID = null;
            //    DropDownList1.DataTextField = "Name";
            //    DropDownList1.DataValueField = "Id";
            //    DropDownList1.DataBind();
            //    GridView1.DataSource = dt;
            //    GridView1.DataSourceID = null;
            //    DropDownList1.Items.Insert(0, "Select All");
            //    DropDownList1.SelectedIndex = 0;
            //    GridView1.DataBind();
            //    sqlcon.Close();

            //}

            //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
            //{
            //string conn = ConfigurationManager.ConnectionStrings["myConnection "].ConnectionString;
            //SqlConnection sqlcon = new SqlConnection(conn);
            //string Sqlqry = "";
            //if (DropDownList1.SelectedItem.ToString() == "Select All")
            //{
            //    Sqlqry = "select * from  employee ";

            //}
            //else
            //{
            //    Sqlqry = "select * from  employee where ID =" + DropDownList1.SelectedValue;

            //}
            ////string Sqlqry = "select * from employee where Id= " + DropDownList1.SelectedValue;
            //SqlCommand cmd = new SqlCommand(Sqlqry, sqlcon);
            //sqlcon.Open();
            //SqlDataAdapter ada = new SqlDataAdapter(cmd);
            //DataTable dt = new DataTable();
            //ada.Fill(dt);
            //GridView1.DataSource = dt;
            //GridView1.DataBind();

            //sqlcon.Close();
        }

        protected void ButSearch_Click(object sender, EventArgs e)
        {
            string co = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sq = new SqlConnection(co);
            sq.Open();
            SqlCommand cd = new SqlCommand();
            string Sq = "select * from employee where Name like '%'+@name+'%'";
            cd.CommandText = Sq;
            cd.Connection = sq;
            cd.Parameters.AddWithValue("Name", TxtSearch.Text);
            DataTable dt9 = new DataTable();
            SqlDataAdapter ada = new SqlDataAdapter(cd) ;
            ada.Fill(dt9);
            GridView2.DataSource = dt9;
            GridView2.DataSourceID = null;
            GridView2.DataBind();
        }

        
    }

}