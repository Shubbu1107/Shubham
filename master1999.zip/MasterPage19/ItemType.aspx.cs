﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;
using System.Configuration;

namespace MasterPage19
{
    public partial class WebForm8 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                databind();

            }

        }
        public void databind()
        {


            string conn = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(conn);
            string Sqlqry = "select * from Itemtype ";
            SqlCommand cmd = new SqlCommand(Sqlqry, sqlcon);
            sqlcon.Open();
           
            SqlDataAdapter ada = new SqlDataAdapter(cmd);

            DataTable dt = new DataTable();
            ada.Fill(dt);
            DropDownList1.DataSource = dt;
            DropDownList1.DataTextField = "ID";
            DropDownList1.DataValueField = "Id";
            DropDownList1.DataBind();
            GridView1.DataSource = dt;
            GridView1.DataSourceID = null;
            DropDownList1.Items.Insert(0, "Select All");
            DropDownList1.SelectedIndex = 0;

            GridView1.DataBind();
            

            sqlcon.Close();

           
        }
        protected void Insertbtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            con.Open();
            SqlCommand cmd = new SqlCommand(@"insert into ItemType(ItemType,Remark) values( '" + Inamebox.Text + "', '" + RemrkBox.Text + "')", con);
            cmd.ExecuteNonQuery();
            con.Close();
            databind();
        }

        protected void Updatebtn_Click(object sender, EventArgs e)
        {
            SqlConnection co = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            co.Open();
            SqlCommand cm = new SqlCommand(@"update ItemType Set ItemType='" + Inamebox.Text + "',Remark='" + RemrkBox.Text + "' where Id ='" + DropDownList1.SelectedValue + "'", co);
            cm.ExecuteNonQuery();
            co.Close();
            databind();
        }

       

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            conn.Open();
            SqlCommand cmdd = new SqlCommand("select * from itemtype");
       

            cmdd.ExecuteNonQuery();
            conn.Close();

        }

        protected void BTNDELL(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            conn.Open();
            SqlCommand cmdd = new SqlCommand(@"delete from Employee  where ID='" + DropDownList1.SelectedValue + "'", conn);
            cmdd.ExecuteNonQuery();
            conn.Close();
            databind();

        }
    }
    

}