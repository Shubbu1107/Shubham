﻿namespace Grid
{
    internal class dataBind
    {
    }
}