﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Web;
using System.Web.DynamicData;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml.Linq;

namespace MasterPage19
{
    public partial class inventoryosiya : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void IbInsert_Click(object sender, EventArgs e)
        {
            SqlDataSource9.InsertParameters["ItemName"].DefaultValue =
                ((DropDownList)GridView1.FooterRow.FindControl("Inameinsert")).SelectedValue;

            SqlDataSource9.InsertParameters["ItemType"].DefaultValue =
               ((DropDownList)GridView1.FooterRow.FindControl("Type")).SelectedValue;

            SqlDataSource9.InsertParameters["AllotedTo"].DefaultValue =
               ((DropDownList)GridView1.FooterRow.FindControl("Employee")).SelectedValue;

            SqlDataSource9.InsertParameters["AllotedDate"].DefaultValue =
               ((TextBox)GridView1.FooterRow.FindControl("Allotdate")).Text;

            SqlDataSource9.InsertParameters["returnDate"].DefaultValue =
              ((TextBox)GridView1.FooterRow.FindControl("ReturnDt")).Text;

            SqlDataSource9.InsertParameters["Remark"].DefaultValue =
              ((TextBox)GridView1.FooterRow.FindControl("Remark")).Text;

            SqlDataSource9.Insert();
        }


        //public static int UpdateInventry(int ID, int ItemName, int ItemType, int AllotedTo, string AllotedDate, string returnDate, string Remark)
        //{
        //        string cs = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
        //        using (SqlConnection conn = new SqlConnection(cs))
        //        {
        //            //string UpdateQuery = "UPDATE [inventry] SET [ItemName]=  @ItemName , [ItemType] = @ItemType, [AllotedTo] = @AllotedTo, [AllotedDate] = @AllotedDate, [returnDate] = @returnDate, [Remark] = @Remark WHERE [ID] = @ID";
        //            //SqlCommand cmd = new SqlCommand("UpdateQuery", conn);
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.CommandText = "UPDATE [inventry] SET [ItemName]=  @ItemName , [ItemType] = @ItemType, [AllotedTo] = @AllotedTo, [AllotedDate] = @AllotedDate, [returnDate] = @returnDate, [Remark] = @Remark WHERE [ID] = @ID";

        //            cmd.CommandType = CommandType.Text;
        //            cmd.Parameters.AddWithValue("@ItemName", ItemName);


        //            conn.Open();
        //            return cmd.ExecuteNonQuery();
        //        }

        //protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        //{
        //    //DropDownList ddl = (DropDownList)GridView1.Rows[e.RowIndex].TemplateControl.FindControl("nameddl");
        //    //string selectedvalue = ddl.SelectedValue;  



        //    DropDownList l = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("nameddl");
        //    DropDownList nameddl = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("nameddl");


        //    DropDownList n = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2");
        //    DropDownList DropDownList2 = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList2");

        //    DropDownList m = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList3");
        //    DropDownList DropDownList3 = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("DropDownList3");

        //    TextBox b = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox4");
        //    TextBox TextBox4 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox4");

        //    TextBox c = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox5");
        //    TextBox TextBox5 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox5");

        //    TextBox d = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox6");
        //    TextBox TextBox6 = (TextBox)GridView1.Rows[e.RowIndex].FindControl("TextBox6");
        //}

        //protected void GridView1_RowUpdating1(object sender, GridViewUpdateEventArgs e)
        //{
        //    DropDownList l = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("nameddl");
        //    DropDownList nameddl = (DropDownList)GridView1.Rows[e.RowIndex].FindControl("nameddl");
        //}

        ////protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        ////{
        ////    GridView1.EditIndex = e.NewEditIndex;
        ////    SqlDataSource1.DataBind();



    }
}