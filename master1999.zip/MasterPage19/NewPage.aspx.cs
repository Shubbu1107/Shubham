﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Configuration;
using System.Net.NetworkInformation;

namespace MasterPage19
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        public object Messagebox { get; private set; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack) // is relaod in same page 
            {
                Datagrid(); // data table name 
            }
        }

        public void Datagrid()
        { 
            //SQL Connection 

            SqlConnection con = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            con.Open();
            SqlDataAdapter adat = new SqlDataAdapter("Select * from employee  ", con);
            DataTable dt = new DataTable();
            adat.Fill(dt);
            // Show Data in GRid View 
            IdDdl.DataSource = dt;
            IdDdl.DataTextField = "Id";
            IdDdl.DataValueField = "Id";
            IdDdl.DataBind();
            GridView2.DataSource = dt;
            GridView2.DataSourceID = null;
            //for Select all in Grid View 
            IdDdl.Items.Insert(0, "Select All");
            IdDdl.SelectedIndex = 0;
            // for Text box Emplty 
            name.Text = String.Empty;
            surname.Text = String.Empty;
            contact.Text = String.Empty;
            DOB.Text = string.Empty;
            Doj.Text = string.Empty;
            email.Text= string.Empty;
            // For DAta BInd 
            GridView2.DataBind();
            con.Close();
           
            if (dt.Rows.Count > 0)
            {
                GridView2.DataSource = dt;
                GridView2.DataBind();
            }

        }
        protected void Insert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            con.Open();
            SqlCommand cmd = new SqlCommand(@"insert into Employee(Name,Surname,Contact,DOB,DOJ,Email) values( '" + name.Text + "', '" + surname.Text + "' , '" + contact.Text + "' , '" + DOB.Text + "',  '" + Doj.Text + "', '" + email.Text + "' )", con);
            cmd.ExecuteNonQuery();
            con.Close();
            Datagrid();
        }

     
        protected void Delete_Click1(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            conn.Open();
            SqlCommand cmdd = new SqlCommand(@"delete from Employee  where ID='" + IdDdl.SelectedValue + "'", conn);
            
            cmdd.ExecuteNonQuery();
            conn.Close();
            Datagrid();
        }

        protected void Update_Click1(object sender, EventArgs e)
        {
            SqlConnection co = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            co.Open();
            SqlCommand cm = new SqlCommand(@"update Employee set name='"+ name.Text + "',surname='"+ surname.Text + "',Contact='"+ contact.Text + "',DOB='"+ DOB.Text + "',DOJ='"+ Doj.Text + "',Email='"+ email.Text + "' where ID='" + IdDdl.SelectedValue + "'", co);
            cm.ExecuteNonQuery();
            co.Close();
            Datagrid();
           
        }

        
    }
}