﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace MasterPage19
{

    public class Inventry
    {
        public int ID { get; set; }
        public int ItemName { get; set; }
        public int ItemType { get; set; }
        public int AllotedTo { get; set; }

        public string AllotedDate { get; set; }
        public string returnDate { get; set; }
        public string Remark { get; set; }


    } 
    public class InventryDataAccessLayer
    {
        public static List<Inventry> GetAllInventry()
        {
            List<Inventry> ListInventry = new List<Inventry>();

            string cs = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("Select * from inventry", conn);
                conn.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    Inventry inventry = new Inventry();
                    inventry.ID = Convert.ToInt32(rdr["ID"]);
                    inventry.ItemName = Convert.ToInt32(rdr["ItemName"]);
                    inventry.ItemType = Convert.ToInt32(rdr["ItemType"]);
                    inventry.AllotedTo = Convert.ToInt32(rdr["AllotedTo"]);
                    inventry.AllotedDate = rdr["AllotedDate"].ToString();
                    inventry.returnDate = rdr["returnDate"].ToString();
                    inventry.Remark = rdr["Remark"].ToString();

                    ListInventry.Add(inventry);
                }
            }
            return ListInventry;
        }

        public static void DeleteInventry(int ID)
        {
            string cs = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("Delete From inventry where ID = @ID", conn);
                SqlParameter prm = new SqlParameter("ID", ID);
                cmd.Parameters.Add(prm);
                conn.Open();
                cmd.ExecuteNonQuery();
            }

        }

        public static int UpdateInventry(int ID, int ItemName, int ItemType, int AllotedTo, string AllotedDate, string returnDate, string Remark)

        {
            string cs = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(cs))
            {
                //string UpdateQuery = "UPDATE [inventry] SET [ItemName]=  @ItemName , [ItemType] = @ItemType, [AllotedTo] = @AllotedTo, [AllotedDate] = @AllotedDate, [returnDate] = @returnDate, [Remark] = @Remark WHERE [ID] = @ID";
                //SqlCommand cmd = new SqlCommand("UpdateQuery", conn);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = "UPDATE [inventry] SET [ItemName]=  @ItemName , [ItemType] = @ItemType, [AllotedTo] = @AllotedTo, [AllotedDate] = @AllotedDate, [returnDate] = @returnDate, [Remark] = @Remark WHERE [ID] = @ID";

                cmd.CommandType = CommandType.Text;
                cmd.Parameters.AddWithValue("@ItemName",ItemName);
             
                //SqlParameter paraminame = new SqlParameter("@ItemName", ItemName);
                //cmd.Parameters.Add(paraminame);

                //SqlParameter paramitype = new SqlParameter("@ItemType", ItemType);
                //cmd.Parameters.Add(paramitype);

                //SqlParameter paramAlloted = new SqlParameter("@AllotedTo", AllotedTo);
                //cmd.Parameters.Add(paramAlloted);

                //SqlParameter paramADate = new SqlParameter("@AllotedDate", AllotedDate);
                //cmd.Parameters.Add(paramADate);

                //SqlParameter paramRDate = new SqlParameter("@returnDate", returnDate);
                //cmd.Parameters.Add(paramRDate);

                //SqlParameter paramRemrk = new SqlParameter("@Remark", Remark);
                //cmd.Parameters.Add(paramRemrk);
                conn.Open();
                return cmd.ExecuteNonQuery();

            }

        }

        public static int InsertInventry(int ID, int ItemName, int ItemType, int AllotedTo, string AllotedDate, string returnDate, string Remark)
        {
            string cs = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            using (SqlConnection conn = new SqlConnection(cs))
            {
                string InsertQuery = "INSERT INTO [inventry] ([ItemName], [ItemType], [AllotedTo], [AllotedDate], [returnDate], [Remark]) VALUES (@ItemName, @ItemType, @AllotedTo, @AllotedDate, @returnDate, @Remark)";
                SqlCommand cmd = new SqlCommand("UpdateQuery", conn);
             

                //SqlParameter paraminame = new SqlParameter("@ItemName", ItemName);
                //cmd.Parameters.Add(paraminame);

                //SqlParameter paramitype = new SqlParameter("@ItemType", ItemType);
                //cmd.Parameters.Add(paramitype);

                //SqlParameter paramAlloted = new SqlParameter("@AllotedTo", AllotedTo);
                //cmd.Parameters.Add(paramAlloted);

                //SqlParameter paramADate = new SqlParameter("@AllotedDate", AllotedDate);
                //cmd.Parameters.Add(paramADate);

                //SqlParameter paramRDate = new SqlParameter("@returnDate", returnDate);
                //cmd.Parameters.Add(paramRDate);

                //SqlParameter paramRemrk = new SqlParameter("@Remark", Remark);
                //cmd.Parameters.Add(paramRemrk);

                conn.Open();
                return cmd.ExecuteNonQuery();

            }

        }

    }
}