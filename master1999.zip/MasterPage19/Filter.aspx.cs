﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterPage19
{
    public partial class Filter : System.Web.UI.Page   
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            SqlConnection  com = new SqlConnection(@"Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            com.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from employee ", com);
            DataSet ds = new DataSet();
            da.Fill(ds);
            grd.DataSource = ds;
            grd.DataSourceID = null;
            grd.DataBind();

        }

        protected void btn1_Click  (object sender, EventArgs e)
        {
            SqlConnection com = new SqlConnection(@"Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            com.Open();
            SqlDataAdapter da = new SqlDataAdapter("select * from Employee where Name like '%" + txt1.Text + "%'", com);       
            DataSet ds = new DataSet();
            da.Fill(ds);
         
            
            grd.DataSourceID = null;

            grd.DataSource = ds;
            grd.DataBind();
        }

        //protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    SqlConnection com = new SqlConnection(@"Data Source=DESKTOP-OJPRKML\SQLEXPRESS;Initial Catalog=training;Persist Security Info=True;User ID=sa; password=pass@w0rd;Pooling=False;Encrypt=False;");
        //    com.Open();
        //    SqlDataAdapter da = new SqlDataAdapter("select * from Employee where Name like '%" + DropDownList1.SelectedValue + "%'", com);
        //    DataSet ds = new DataSet();
        //    da.Fill(ds);
        //    grd.DataSourceID = null;
        //    grd.DataSource = ds;
        //    grd.DataBind();
        //}
    }
}