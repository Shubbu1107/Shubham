﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterPage19
{
    public partial class WebForm9 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DataBind();
            }
        }

      

        protected void IbInsert_Click(object sender, EventArgs e)
        {
            SqlConnection cooon = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd;Pooling=False;Encrypt=False;");
            cooon.Open();
            SqlCommand cmdff = new SqlCommand(@"insert into inventry(ItemName,ItemType,AllotedTo,AllotedDate,Remark) values('" + inameddl0.SelectedValue + "', '" + itypeddl0.SelectedValue + "' , '" + iAlloteddl0.SelectedValue + "' , '" + AllotedDatebox0.Text + "',  '" + Remarkbox0.Text + "' )", cooon);
            cmdff.ExecuteNonQuery();
            cooon.Close();
            GridView1.DataBind();
            DataBind();

        }

        protected void itypeddl0_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void inameddl0_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void SqlDataSource7_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
        {

        }
    }
}