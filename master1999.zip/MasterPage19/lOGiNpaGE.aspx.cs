﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MasterPage19
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=WIN-SERVER;Initial Catalog=OsiyaInventry;User ID=sa;Password=pass@w0rd");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Employee where name ='" + TextBox1.Text + "' and surname='" + TextBox2.Text + "'",con  );
            SqlDataReader dr = cmd.ExecuteReader();
            if(dr.HasRows)
            {
                Response.Redirect("NewPage.aspx");
            }
            else
            {
                Console.WriteLine("Incorrect Information ");
            }
            con.Close();
        }
    }
} 