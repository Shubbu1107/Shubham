﻿                                      using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Drawing;
using System.Globalization;


namespace MasterPage19
{
    public partial class trynew : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void ButSearch_Click(object sender, EventArgs e)
        {
            string conn = ConfigurationManager.ConnectionStrings["WinServer"].ConnectionString;
            SqlConnection sqlcon = new SqlConnection(conn);
            sqlcon.Open();
            SqlCommand cmd = new SqlCommand();
            string Sqlqry = "select * from employee where Name like '%'+@name+'%'";
            cmd.CommandText = Sqlqry;
            cmd.Connection = sqlcon;    
            cmd.Parameters.AddWithValue("Name",TxtSearch.Text);
            DataTable dt = new DataTable(); 
            SqlDataAdapter ada = new SqlDataAdapter(cmd);
            ada.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
    }

    

}
